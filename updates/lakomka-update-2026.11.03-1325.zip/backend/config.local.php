<?php
/* Локальный конфиг песочницы (в git не попадает). Сгенерирован для сессии. */
return [
    'jwt_secret' => '4ec823dedd1989dc1dcb8d7f29c8ad011ad03ff6c29c7b048892004905b160d3',
    'encryption_key' => '58a474bf3ba28d5a2d45d336fa73a1da193d7054d6b21be9b9c6390b55531fad',
    'admin_email' => 'admin@lakomka.local',
    'debug' => false,
];
