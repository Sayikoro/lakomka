<?php return ["jwt_secret"=>"15316eebe4b116ad0db4c4b1106b36249273804aa213d0cf7b30e1d494a0ddca","encryption_key"=>"4f595e5f3430e36705dbfffbc3402080a2fd529d13627e2b9b6eac6468d4a179","debug"=>false];
