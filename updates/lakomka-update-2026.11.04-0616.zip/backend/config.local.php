<?php
/* Песочница: литеральные ключи (Task 138). ВАЖНО: literal, не random_bytes() —
   иначе JWT-секрет плавает между запросами и тесты падают «Token invalid». */
return [
    'jwt_secret' => 'f27ab2c07702ff40c035ee7c7537a7f9918be95b96fd62b347b8a12a0e96dfed',
    'encryption_key' => '0991069ec3ec947f2195de467435b4187f2ba89f3f7f75a5db9d3f96522dfb27',
    'admin_email' => 'admin@lakomka.local',
    'debug' => false,
];
