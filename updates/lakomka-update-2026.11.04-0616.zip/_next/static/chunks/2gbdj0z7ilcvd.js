(()=>{"use strict";(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,12339,e=>{let t=e.i(47167).default.env.NEXT_PUBLIC_API_URL??"/api";async function r(e,r){let a=Math.ceil(e.size/524288);if(a>2e3)throw Error("Файл слишком большой (>1 GB). Разделите на части.");let o="up-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,10);for(let n=0;n<a;n++){let i=524288*n,s=Math.min(i+524288,e.size),l=e.slice(i,s),f=function(e){let t="",r=e.byteLength;for(let a=0;a<r;a+=32768)t+=String.fromCharCode.apply(null,Array.from(e.subarray(a,Math.min(a+32768,r))));return btoa(t)}(new Uint8Array(await l.arrayBuffer())),c=await fetch(`${t}/admin/upload/chunk`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({upload_id:o,chunk_index:n,total_chunks:a,filename:e.name,chunk_base64:f})});if(!c.ok)throw Error((await c.json().catch(()=>({}))).error??`Ошибка чанка ${n+1}/${a}`);let u=await c.json();if(r?.(Math.round((n+1)/a*100)),u.data?.done)return{filePath:u.data.file_name,size:u.data.size}}throw Error("Загрузка не завершилась")}e.s(["f",0,r])},22715,e=>{let t={enabled:!1,count:110,count_mobile:60,speed:.5,size:31,color:"#f5f5f5",flake:""},r=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="#fff">
  <defs>
    <g id="a">
      <rect x="30" y="4" width="4" height="22" rx="2"/>
      <rect x="26.5" y="7" width="3.5" height="11" rx="1.75" transform="rotate(-55 28.25 12.5)"/>
      <rect x="34" y="7" width="3.5" height="11" rx="1.75" transform="rotate(55 35.75 12.5)"/>
    </g>
  </defs>
  <use href="#a"/>
  <use href="#a" transform="rotate(60 32 32)"/>
  <use href="#a" transform="rotate(120 32 32)"/>
  <use href="#a" transform="rotate(180 32 32)"/>
  <use href="#a" transform="rotate(240 32 32)"/>
  <use href="#a" transform="rotate(300 32 32)"/>
  <circle cx="32" cy="32" r="3.5"/>
</svg>`,a="data:image/svg+xml;charset=utf-8,"+encodeURIComponent(r);e.s(["u",0,a,"V",0,r,"a",0,t,"X",0,function(e){let r=e??{},a=(e,t,r,a,o=!1)=>{let n="number"==typeof e?e:parseFloat(String(e??""));if(!Number.isFinite(n))return t;let i=Math.max(r,Math.min(a,n));return o?Math.round(i):i};return{enabled:!0===r.enabled||1===r.enabled||"1"===String(r.enabled??"").toLowerCase()||"true"===String(r.enabled??"").toLowerCase(),count:a(r.count,t.count,0,500,!0),count_mobile:a(r.count_mobile,t.count_mobile,0,500,!0),speed:a(r.speed,t.speed,.1,20),size:a(r.size,t.size,4,120,!0),color:"string"==typeof r.color&&/^#[0-9a-fA-F]{6}$/.test(r.color)?r.color:t.color,flake:"string"==typeof r.flake?r.flake:""}}])}])})();