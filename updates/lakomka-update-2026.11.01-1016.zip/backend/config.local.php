<?php
/**
 * ЛОКАЛЬНЫЕ СЕКРЕТЫ (dev-стенд, не коммитится).
 * Статические значения НЕ случайны: при random_bytes() на каждый запрос
 * JWT-подпись менялась между воркерами и /api/auth/me отдавал 401.
 */
$config['jwt_secret']     = 'e2e-lakomka-jwt-secret-0f3a9c8d2b7e5614a9f0';
$config['encryption_key'] = 'e2e-lakomka-enc-key-91c4b7d3e8f2a6150dbc';
