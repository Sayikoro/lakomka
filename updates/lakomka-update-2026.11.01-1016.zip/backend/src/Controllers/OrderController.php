<?php

require_once __DIR__ . '/../Crypto.php';

class OrderController
{
    public static function create(PDO $pdo): void
    {
        /* Анти-флуд: публичный эндпоинт создаёт заказы, списывает сток и
           запускает письма через SMTP магазина — без лимита это и спам-дренаж,
           и mail-бомбинг. 5 заказов в час с одного IP. */
        self::assertNotFlooding($pdo);

        $raw = file_get_contents('php://input');
        $payload = json_decode($raw, true);

        if (!is_array($payload)) {
            self::fail('Invalid JSON', 400);
        }

        $name    = trim((string)($payload['customer_name'] ?? ''));
        $phone   = trim((string)($payload['customer_phone'] ?? ''));
        $email   = trim((string)($payload['customer_email'] ?? ''));
        $method  = (string)($payload['delivery_method'] ?? '');
        $address = trim((string)($payload['address'] ?? ''));
        $comment = trim((string)($payload['comment'] ?? ''));
        $items   = $payload['items'] ?? [];

        if ($name === '')  self::fail('Укажите имя', 422);
        if ($phone === '') self::fail('Укажите телефон', 422);
        if (mb_strlen($name) > 100)    $name = mb_substr($name, 0, 100);
        if (mb_strlen($phone) > 30)    self::fail('Слишком длинный номер телефона', 422);
        if (mb_strlen($address) > 300) self::fail('Слишком длинный адрес', 422);
        if (mb_strlen($comment) > 1000) self::fail('Слишком длинный комментарий', 422);
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            self::fail('Некорректный email', 422);
        }
        if ($email !== '' && mb_strlen($email) > 120) self::fail('Слишком длинный email', 422);
        if (!in_array($method, ['pickup', 'city', 'region', 'tk'], true)) {
            self::fail('Некорректный способ доставки', 422);
        }
        if (!is_array($items) || count($items) === 0) {
            self::fail('Корзина пуста', 422);
        }
        if (count($items) > 50) {
            self::fail('Слишком много позиций в заказе', 422);
        }

        $pdo->exec('BEGIN IMMEDIATE');

        try {
            $checkStmt = $pdo->prepare(
                'SELECT id, name, price_kopecks, stock_qty
                 FROM products
                 WHERE id = ? AND is_published = 1'
            );

            $lines = [];
            $total = 0;

            foreach ($items as $row) {
                $productId = (int)($row['product_id'] ?? 0);
                $qty = (int)($row['qty'] ?? 0);

                if ($productId <= 0 || $qty <= 0 || $qty > 999) {
                    throw new RuntimeException('Некорректная позиция корзины');
                }

                $checkStmt->execute([$productId]);
                $product = $checkStmt->fetch();

                if (!$product) {
                    throw new RuntimeException("Товар #{$productId} не найден");
                }
                if ($product['stock_qty'] < $qty) {
                    throw new RuntimeException(
                        "«{$product['name']}»: осталось {$product['stock_qty']} шт."
                    );
                }

                $lineSum = $product['price_kopecks'] * $qty;
                $total  += $lineSum;

                $lines[] = [
                    'product_id'    => (int)$product['id'],
                    'product_name'  => $product['name'],
                    'qty'           => $qty,
                    'price_kopecks' => (int)$product['price_kopecks'],
                ];
            }

            $orderNumber = 'ЛК-' . date('Ymd') . '-' . str_pad(
                (string)random_int(1, 9999),
                4,
                '0',
                STR_PAD_LEFT
            );

            // Шифруем PII перед сохранением
            $insertOrder = $pdo->prepare(
                'INSERT INTO orders
                    (order_number, customer_name, customer_phone, customer_phone_hash,
                     customer_email, delivery_method, address, comment,
                     total_kopecks, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );
            $insertOrder->execute([
                $orderNumber,
                Crypto::encrypt($name),
                Crypto::encrypt($phone),
                Crypto::phoneHash($phone),
                $email !== '' ? Crypto::encrypt($email) : null,
                $method,
                $address !== '' ? Crypto::encrypt($address) : null,
                $comment !== '' ? Crypto::encrypt($comment) : null,
                $total,
                'new',
            ]);

            $orderId = (int)$pdo->lastInsertId();

            $insertItem = $pdo->prepare(
                'INSERT INTO order_items
                    (order_id, product_id, product_name, qty, price_kopecks)
                 VALUES (?, ?, ?, ?, ?)'
            );
            $deductStock = $pdo->prepare(
                'UPDATE products SET stock_qty = stock_qty - ? WHERE id = ?'
            );

            foreach ($lines as $line) {
                $insertItem->execute([
                    $orderId,
                    $line['product_id'],
                    $line['product_name'],
                    $line['qty'],
                    $line['price_kopecks'],
                ]);
                $deductStock->execute([$line['qty'], $line['product_id']]);
            }

            $pdo->prepare(
                'INSERT INTO order_status_history (order_id, status, comment)
                 VALUES (?, ?, ?)'
            )->execute([$orderId, 'new', 'Заказ создан клиентом']);

            $pdo->exec('COMMIT');

            // Фиксируем заказ в анти-флуд-счётчике и чистим старые записи
            try {
                $pdo->prepare('INSERT INTO order_rate (ip) VALUES (?)')
                    ->execute([self::clientIp()]);
                $pdo->exec("DELETE FROM order_rate WHERE created_at < datetime('now', '-1 day')");
            } catch (Throwable $ignored) {
            }

            // Письма — после COMMIT, ошибки не ломают ответ.
            // Статус письма клиенту фиксируем в orders.email_sent / email_error,
            // чтобы админка показала красный маркер и кнопку «Отправить клиенту».
            $emailSent = null;   // NULL — письма не требовалось (нет email)
            $emailError = null;
            try {
                require_once __DIR__ . '/../Mailer.php';
                $mailer = new Mailer();
                $fullOrder = [
                    'order_number'    => $orderNumber,
                    'customer_name'   => $name,     // в письме — открытым
                    'customer_phone'  => $phone,
                    'delivery_method' => $method,
                    'address'         => $address,
                    'comment'         => $comment,
                    'total_kopecks'   => $total,
                ];
                if ($email !== '') {
                    $okCustomer = $mailer->sendOrderToCustomer($fullOrder, $lines, $email);
                    $emailSent  = $okCustomer ? 1 : 0;
                    $emailError = $okCustomer
                        ? null
                        : ($mailer->lastError !== '' ? $mailer->lastError : 'Неизвестная ошибка отправки');
                }
                $mailer->sendOrderToAdmin($fullOrder, $lines);
            } catch (Throwable $mailErr) {
                error_log('[mail] ' . $mailErr->getMessage());
                if ($email !== '' && $emailSent === null) {
                    $emailSent = 0;
                    $emailError = $mailErr->getMessage();
                }
            }
            if ($emailSent !== null) {
                $pdo->prepare('UPDATE orders SET email_sent = ?, email_error = ? WHERE id = ?')
                    ->execute([$emailSent, $emailError, $orderId]);
            }

            // Telegram-уведомление админу (Task 108) — рядом с письмом, после
            // COMMIT; любая ошибка (сеть, неверный токен) НЕ ломает ответ заказа.
            try {
                require_once __DIR__ . '/../Telegram.php';
                [$tgOk, $tgErr] = Telegram::sendMessage(
                    $pdo,
                    self::telegramText($orderNumber, $name, $phone, $method, $address, $comment, $total, $lines)
                );
                if (!$tgOk) {
                    error_log('[telegram] ' . $tgErr);
                }
            } catch (Throwable $tg) {
                error_log('[telegram] ' . $tg->getMessage());
            }

            jsonResponse([
                'data' => [
                    'order_id'      => $orderId,
                    'order_number'  => $orderNumber,
                    'total_kopecks' => $total,
                    'status'        => 'new',
                ],
            ], 201);

        } catch (Throwable $e) {
            $pdo->exec('ROLLBACK');
            self::fail($e->getMessage(), 422);
        }
    }

    private static function fail(string $message, int $status = 400): never
    {
        jsonResponse(['error' => $message], $status);
    }

    /* ============================================================
       ТЕКСТ TELEGRAM-СООБЩЕНИЯ О ЗАКАЗЕ (Task 108)
       ============================================================ */

    /** Человекочитаемые названия способов доставки (как в чекауте витрины) */
    private const DELIVERY_LABELS = [
        'pickup' => 'Самовывоз',
        'city'   => 'Доставка по городу',
        'region' => 'Доставка по краю',
        'tk'     => 'Транспортная компания',
    ];

    private static function money(int $kopecks): string
    {
        return number_format($kopecks / 100, 0, '.', ' ') . ' ₽';
    }

    private static function telegramText(
        string $orderNumber,
        string $name,
        string $phone,
        string $method,
        string $address,
        string $comment,
        int $total,
        array $lines
    ): string {
        $delivery = self::DELIVERY_LABELS[$method] ?? $method;
        $text  = "🛒 Новый заказ {$orderNumber} на " . self::money($total) . "\n";
        $text .= "\n👤 {$name} — ☎ {$phone}";
        $text .= "\n🚚 {$delivery}";
        if ($address !== '') {
            $text .= "\n📍 {$address}";
        }
        if ($comment !== '') {
            $text .= "\n💬 {$comment}";
        }
        $text .= "\n\nТовары:";
        foreach ($lines as $l) {
            $sum = self::money((int)$l['price_kopecks'] * (int)$l['qty']);
            $text .= "\n• {$l['product_name']} × {$l['qty']} — {$sum}";
        }
        return $text;
    }

    /* ============================================================
       АНТИ-ФЛУД (рейт-лимит заказов)
       ============================================================ */

    private static function clientIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = explode(',', (string)$_SERVER[$k])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '0.0.0.0';
    }

    private static function assertNotFlooding(PDO $pdo): void
    {
        try {
            $stmt = $pdo->prepare(
                "SELECT COUNT(*) FROM order_rate
                 WHERE ip = ? AND created_at > datetime('now', '-60 minutes')"
            );
            $stmt->execute([self::clientIp()]);
            if ((int)$stmt->fetchColumn() >= 5) {
                self::fail('Слишком много заказов за последний час. Позвоните нам — оформим вручную.', 429);
            }
        } catch (Throwable $e) {
            // Таблицы ещё нет (сайт обновился с голосой базы) — создаём и идём дальше
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS order_rate (
                    ip TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT (datetime('now'))
                )");
                $pdo->exec('CREATE INDEX IF NOT EXISTS idx_order_rate_ip ON order_rate(ip, created_at)');
            } catch (Throwable $ignored) {
            }
        }
    }
}